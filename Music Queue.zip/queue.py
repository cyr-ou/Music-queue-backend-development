from __future__ import annotations
from song import Song

def load_song_from_input(input_song: str) -> Song:
    '''
    Parse the input song and extract all song's information
    Create a Song object based on that

    @parameters:
    - input_song(str): The string that contains the song information

    @returns:
    - Song: The Song object that contains song's information
    '''
    #to split user input into a list
    user_input=input_song.strip().split(',')
    if len(user_input)!=5:
        return None
    operation,song_name,artist,genre,duration=user_input
    return Song(song_name.strip(), artist.strip(), genre.strip(), duration.strip())


def add_song(queue: list[Song], song: Song)-> None:
    '''
    Adds a song to the queue if the user chooses to add.
    Error/successful messages will be printed inside this function.

    Checks if a song with the same name and artist already exists in the queue.
    If it does, it prints a message indicating the song is already present.
    Otherwise, it adds the song to the queue and 
    prints a message indicating successful addition.

    @parameters:
    - queue (list[Song]): The list of Song objects representing the queue.
    - song (Song): The Song object to be added to the queue.


    '''
    #iterate in the queue list to append the new inputed song
    for exist_song in queue:
        if exist_song.get_name()==song.get_name() and exist_song.get_artist()==song.get_artist():
            print(f"***'{song.get_name()}' by {song.get_artist()} is already in the queue***")
            return
    queue.append(song)
    print(f"***'{song.get_name()}' by {song.get_artist()} is added to the queue***")

def remove_song(queue: list[Song], song: Song)-> None:
    '''
    Removes a song from the queue if it exists.
    Error/successful messages will be printed inside this function.
    
    Checks if a song exists in the queue.
    If it does, remove it from the queue and prints a successful message.
    Otherwise, prints a corresponding error message.

    @parameters:
    - queue (list[Song]): The list of Song objects representing the queue.
    - song (Song): The Song object to be removed from the queue.
    '''
    #judge wether the queue is empty
    if queue==[]:
        print(f"***No '{song.get_name()}' by {song.get_artist()} found, cannot remove it***")
        return
    #iterate in the list to find the existed song and remove it
    #iterate from the first element in the queue
    i=0
    for exist_song in queue:
        if exist_song.get_name()==song.get_name() and exist_song.get_artist()==song.get_artist():
            queue.pop(i)
            print(f"***Successfully removed '{song.get_name()}' by {song.get_artist()}***")
            return
        i+=1
    print(f"***No '{song.get_name()}' by {song.get_artist()} found, cannot remove it***")

def replace_song(queue: list[Song], song: Song, position: str) -> None:
    '''
    Swaps a song in the queue with another song at a specified position.
    Error/successful messages will be printed inside this function.

    Checks if the provided position is valid. 
    If valid, it removes the song exisiting at that position and replaces it with specified song 
    and prints a message indicating successful swap. 
    Otherwise, it prints an error message depending 
    on the error (not integer, negative, or out of range).

    @parameters:
    - queue (list[Song]): The list of Song objects representing the queue.
    - song (Song): The Song object to be moved into the queue.
    - position (str): The position of the song to be swapped (zero-based indexing).
    '''
    #ensure the position is smaller than len(queue)
    try:
        position=int(position)
        if position<0:
            print("***Position must be at least 0***")
        elif position>=len(queue):
            print("***The specified position is out of range of the queue***")
        else:
            print(f"***Successfully replaced '{queue[position].song_name}' by {queue[position].artist} to '{song.song_name}' by {song.artist}***")
            queue.pop(position)
            #insert the song to the removed position
            queue.insert(position,song)
    except ValueError:
        print('***Position must be an integer***')

def write_queue(filename: str, queue: list[Song], queue_mode: str)-> None:
    '''
    Writes all Song objects stored in the queue variable to the output file in the queue_info directory. 
    The file-open mode depends on the selected queue mode:
        - CREATE: Create a new file to store the queue.
        - RESET: Overwrite the contents of the file.
        - APPEND: Write the new queue below the old queue.
    Each song in the queue is written as a single line in the output file. 

    The format of each line:
    <song name>,<artist>,<genre>,<song duration>

    @parameters:
    - queue (list[Song]): A list of Song object that inside the queue
    - queue_mode(str): the mode of the queue (RESET/APPEND/CREATE)
    '''
    #set the mode excute on the file based on the queue_mode
    if queue_mode=='CREATE':
        mode='w'
    elif queue_mode=='RESET':
        mode='w' # overwrite the file
    elif queue_mode=='APPEND':
        mode='a'
    else:
        print('Error!')
        return

    # Ensure the 'queue_info' directory exists.
    # Write the queue to the file
    with open(f'{filename}', mode) as file:
        for song in queue:
            file.write(f'{song.get_name()},{song.get_artist()},{song.get_genre()},{song.get_duration()}\n')


def main():
    '''
    Where your main program will run
    '''

    # A list temporarily stores all Song object in the queue
    queue = []

    ### SELECTING QUEUE MODE ###
    # Check if queue already exists
    # Check for RESET mode
    # Check for APPEND mode
    import sys
    if len(sys.argv)==1:
        print('No <username> found!')
        return

    queue_mode=None
    while True:
        try:
            with open('queue_info/'+sys.argv[1]+'_queue.txt') as file:
                user_input=input('Do you want to reset or append to your queue? ')
                if user_input.upper()=="APPEND":
                    print('Appending to your queue...')
                    queue_mode='APPEND'
                    break
                elif user_input.upper()=="RESET":
                    print('Resetting your queue...')
                    queue_mode='RESET'
                    break
                else:
                    print('Invalid mode!')
        except:
            print(f'No queue for {sys.argv[1]} found! Creating a new queue...')
            queue_mode='CREATE'
            break
            
    # Prompt for song's details
    # Verify whether the argument for <operation> is valid
    while True:
        print()
        user_input=input('Update songs in the queue: ').strip()

        if user_input=='END QUEUE':
            break
        # Load the song from input
        song=load_song_from_input(user_input)
        if user_input.lower()=='done':
            break
        elif user_input[0]=='X':
            print('***Invalid operation!***')
            continue
        elif user_input[0]=='R':
            remove_song(queue,song)
            continue
        elif user_input[0]=='S':
            user_position_input=input('Which position do you want to replace this song with? ')
            replace_song(queue,song,user_position_input)
            continue

        # Add the song to the queue
        if song:
            add_song(queue,song)

    # Write to the output file
    filename=sys.argv[1]+'_queue.txt'
    write_queue(f'queue_info/{filename}',queue,queue_mode)
    
if __name__ == "__main__":
    main()

